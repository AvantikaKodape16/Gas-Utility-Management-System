from rest_framework import viewsets
from .models import ServiceRequest, CustomerAccount
from .serializers import ServiceRequestSerializer, CustomerAccountSerializer
from rest_framework.permissions import IsAuthenticated

class ServiceRequestViewSet(viewsets.ModelViewSet):
    queryset = ServiceRequest.objects.all()
    serializer_class = ServiceRequestSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

class CustomerAccountViewSet(viewsets.ModelViewSet):
    queryset = CustomerAccount.objects.all()
    serializer_class = CustomerAccountSerializer
    permission_classes = [IsAuthenticated]
